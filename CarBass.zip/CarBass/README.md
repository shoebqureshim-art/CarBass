# Car Bass

A simple bass booster and equalizer for Android car head units. Big sliders, presets, and it keeps working in the background.

## Features
- **On/Off** switch
- **Presets:** Flat, Bass Heavy, Bass + Clear, Night
- **Bass Boost** (0–100%)
- **Loudness** (up to +10 dB)
- **Equalizer** with however many bands your head unit supports (usually 5)
- Runs in the background and starts again when the head unit boots

## Build the APK (free, no Android Studio needed)
1. Create a new repository on GitHub (e.g. `CarBass`).
2. Click **"uploading an existing file"** and drag in everything from this folder, **including the `.github` folder**.
   - On a computer it's easiest to unzip first and drag the folder contents in.
3. Commit. Go to the **Actions** tab. The "Build APK" job runs automatically (about 3–5 minutes).
4. Open the finished run and download **CarBass-apk** from *Artifacts*. Unzip it to get `app-debug.apk`.

## Or build with Android Studio
Open this folder in Android Studio → let it sync → **Build → Build APK(s)**.

## Install on the head unit
1. Copy `app-debug.apk` to a USB stick.
2. On the head unit, open the file manager → tap the APK → allow "Install unknown apps" if asked.
3. Open **Car Bass** and allow notifications (that keeps it running).

## If it says "Global EQ not allowed"
Some head units block system-wide effects. The app still works on music apps that announce their audio (Spotify, YouTube Music, Poweramp). Start the music first, then open Car Bass.

## Safety
Go easy on bass at high volume. Too much boost can tear the speaker foam again.
