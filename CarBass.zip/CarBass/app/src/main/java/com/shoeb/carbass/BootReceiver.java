package com.shoeb.carbass;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Turns the bass back on when the head unit starts up. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Prefs.get(context).getBoolean(Prefs.ENABLED, true)) {
            BassService.start(context);
        }
    }
}
