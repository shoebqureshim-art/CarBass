package com.shoeb.carbass;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.audiofx.AudioEffect;
import android.os.Build;
import android.os.IBinder;

import java.util.HashMap;
import java.util.Map;

/**
 * Keeps the effects alive in the background.
 * Session 0 = global output (works on most head units).
 * Players like Spotify/YouTube Music also announce their own sessions; we attach to those too.
 */
public class BassService extends Service implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final String CHANNEL = "carbass";
    private static final int NOTIF_ID = 1;

    /** True once the global (session 0) effects attached; the screen shows this. */
    static volatile boolean globalOk = false;
    static volatile int sessionCount = 0;

    private final Map<Integer, Fx> sessions = new HashMap<>();
    private SharedPreferences prefs;

    private final BroadcastReceiver sessionRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int s = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
            if (s <= 0) return;
            if (AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION.equals(intent.getAction())) {
                attach(s);
            } else if (AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION.equals(intent.getAction())) {
                detach(s);
            }
        }
    };

    static void start(Context c) {
        Intent i = new Intent(c, BassService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Throwable ignored) {
            // Some Android versions refuse background starts; the app screen will start it instead.
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        goForeground();
        prefs = Prefs.get(this);
        prefs.registerOnSharedPreferenceChangeListener(this);

        attach(0);
        Fx global = sessions.get(0);
        globalOk = global != null;

        IntentFilter f = new IntentFilter();
        f.addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION);
        f.addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(sessionRx, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(sessionRx, f);
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Car Bass", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = b.setSmallIcon(R.drawable.ic_speaker)
                .setContentTitle("Car Bass is on")
                .setContentText("Tap to adjust bass and EQ")
                .setContentIntent(open)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void attach(int session) {
        if (sessions.containsKey(session)) return;
        Fx fx = new Fx(session);
        if (!fx.hasAny()) return;
        fx.apply(prefs);
        sessions.put(session, fx);
        sessionCount = sessions.size();
    }

    private void detach(int session) {
        Fx fx = sessions.remove(session);
        if (fx != null) fx.release();
        sessionCount = sessions.size();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        for (Fx fx : sessions.values()) fx.apply(p);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(sessionRx); } catch (Throwable ignored) {}
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
        for (Fx fx : sessions.values()) fx.release();
        sessions.clear();
        globalOk = false;
        sessionCount = 0;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
