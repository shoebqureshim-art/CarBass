package com.shoeb.carbass;

import android.content.SharedPreferences;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.util.Log;

/** The three audio effects attached to one audio session. */
final class Fx {
    private static final String TAG = "CarBass";
    private static final int PRIORITY = 1000;

    final int session;
    private Equalizer eq;
    private BassBoost bass;
    private LoudnessEnhancer loud;

    Fx(int session) {
        this.session = session;
        try { eq = new Equalizer(PRIORITY, session); } catch (Throwable t) { Log.w(TAG, "No equalizer on " + session, t); }
        try { bass = new BassBoost(PRIORITY, session); } catch (Throwable t) { Log.w(TAG, "No bass boost on " + session, t); }
        try { loud = new LoudnessEnhancer(session); } catch (Throwable t) { Log.w(TAG, "No loudness on " + session, t); }
    }

    boolean hasAny() {
        return eq != null || bass != null || loud != null;
    }

    void apply(SharedPreferences p) {
        boolean on = p.getBoolean(Prefs.ENABLED, true);

        if (eq != null) {
            try {
                short bands = eq.getNumberOfBands();
                short[] range = eq.getBandLevelRange();
                for (short b = 0; b < bands; b++) {
                    int level = p.getInt(Prefs.BAND + b, 0);
                    level = Math.max(range[0], Math.min(range[1], level));
                    eq.setBandLevel(b, (short) level);
                }
                eq.setEnabled(on);
            } catch (Throwable t) { Log.w(TAG, "EQ apply failed", t); }
        }

        if (bass != null) {
            try {
                int s = p.getInt(Prefs.BASS, 0);
                if (bass.getStrengthSupported()) bass.setStrength((short) s);
                bass.setEnabled(on && s > 0);
            } catch (Throwable t) { Log.w(TAG, "Bass apply failed", t); }
        }

        if (loud != null) {
            try {
                int g = p.getInt(Prefs.LOUD, 0);
                loud.setTargetGain(g);
                loud.setEnabled(on && g > 0);
            } catch (Throwable t) { Log.w(TAG, "Loudness apply failed", t); }
        }
    }

    void release() {
        if (eq != null) { try { eq.release(); } catch (Throwable ignored) {} eq = null; }
        if (bass != null) { try { bass.release(); } catch (Throwable ignored) {} bass = null; }
        if (loud != null) { try { loud.release(); } catch (Throwable ignored) {} loud = null; }
    }
}
