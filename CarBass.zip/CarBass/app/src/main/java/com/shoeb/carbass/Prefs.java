package com.shoeb.carbass;

import android.content.Context;
import android.content.SharedPreferences;

/** Saved settings shared by the screen and the background service. */
final class Prefs {
    static final String FILE = "carbass";
    static final String ENABLED = "enabled";
    static final String BASS = "bass";          // BassBoost strength, 0..1000
    static final String LOUD = "loud";          // LoudnessEnhancer gain in millibels, 0..1000
    static final String BAND = "band_";         // + band index, level in millibels

    static final int BASS_MAX = 1000;
    static final int LOUD_MAX = 1000;           // +10 dB, enough without wrecking speakers

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }
}
