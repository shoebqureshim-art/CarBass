package com.shoeb.carbass;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.audiofx.Equalizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

/** One big, car-friendly screen: on/off, bass, loudness, EQ bands and presets. */
public class MainActivity extends Activity {
    private static final int ORANGE = 0xFFFF6A00;

    private SharedPreferences prefs;

    // Equalizer layout, read from the device
    private int bandCount = 5;
    private int[] centerHz = {60, 230, 910, 3600, 14000};
    private int minLevel = -1500, maxLevel = 1500;   // millibels
    private boolean eqInfoOk = false;

    private SeekBar bassBar, loudBar;
    private TextView bassLabel, loudLabel, status;
    private SeekBar[] bandBars;
    private TextView[] bandLabels;
    private Switch enabledSwitch;

    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = Prefs.get(this);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        BassService.start(this);

        readEqInfo();
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        BassService.start(this);
        handler.postDelayed(this::updateStatus, 800);
    }

    /** Ask the device how many EQ bands it has and their frequencies. */
    private void readEqInfo() {
        Equalizer probe = null;
        try {
            probe = new Equalizer(0, 0);
            bandCount = probe.getNumberOfBands();
            short[] r = probe.getBandLevelRange();
            minLevel = r[0];
            maxLevel = r[1];
            centerHz = new int[bandCount];
            for (short b = 0; b < bandCount; b++) centerHz[b] = probe.getCenterFreq(b) / 1000;
            eqInfoOk = true;
        } catch (Throwable t) {
            eqInfoOk = false;
        } finally {
            if (probe != null) try { probe.release(); } catch (Throwable ignored) {}
        }
    }

    // ---------- UI ----------

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF111111);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        // Header row: title + on/off
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Car Bass", 32, Color.WHITE, true);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        enabledSwitch = new Switch(this);
        enabledSwitch.setText("ON ");
        enabledSwitch.setTextColor(Color.WHITE);
        enabledSwitch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        enabledSwitch.setChecked(prefs.getBoolean(Prefs.ENABLED, true));
        enabledSwitch.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean(Prefs.ENABLED, on).apply());
        header.addView(enabledSwitch);
        root.addView(header);

        status = text("", 15, 0xFF9E9E9E, false);
        root.addView(status);

        // Presets
        root.addView(section("Presets"));
        LinearLayout presets = new LinearLayout(this);
        presets.addView(presetButton("Flat", 0), weight());
        presets.addView(presetButton("Bass Heavy", 1), weight());
        presets.addView(presetButton("Bass + Clear", 2), weight());
        presets.addView(presetButton("Night", 3), weight());
        root.addView(presets);

        // Bass boost
        root.addView(section("Bass Boost"));
        bassLabel = text("", 20, Color.WHITE, false);
        root.addView(bassLabel);
        bassBar = bar(Prefs.BASS_MAX, prefs.getInt(Prefs.BASS, 0), (v) -> {
            prefs.edit().putInt(Prefs.BASS, v).apply();
            bassLabel.setText(String.format(Locale.US, "Strength: %d%%", v / 10));
        });
        root.addView(bassBar);

        // Loudness
        root.addView(section("Loudness"));
        loudLabel = text("", 20, Color.WHITE, false);
        root.addView(loudLabel);
        loudBar = bar(Prefs.LOUD_MAX, prefs.getInt(Prefs.LOUD, 0), (v) -> {
            prefs.edit().putInt(Prefs.LOUD, v).apply();
            loudLabel.setText(String.format(Locale.US, "Gain: +%.1f dB", v / 100f));
        });
        root.addView(loudBar);

        // Equalizer bands
        root.addView(section("Equalizer"));
        bandBars = new SeekBar[bandCount];
        bandLabels = new TextView[bandCount];
        for (int i = 0; i < bandCount; i++) {
            final int band = i;
            bandLabels[i] = text("", 18, Color.WHITE, false);
            root.addView(bandLabels[i]);
            int saved = clamp(prefs.getInt(Prefs.BAND + i, 0));
            bandBars[i] = bar(maxLevel - minLevel, saved - minLevel, (v) -> {
                int level = v + minLevel;
                prefs.edit().putInt(Prefs.BAND + band, level).apply();
                bandLabels[band].setText(String.format(Locale.US, "%s:  %+.1f dB", hz(centerHz[band]), level / 100f));
            });
            root.addView(bandBars[i]);
        }

        TextView note = text("Tip: keep it under ~70% bass at high volume so you don't blow the speakers again.",
                14, 0xFF9E9E9E, false);
        note.setPadding(0, dp(24), 0, 0);
        root.addView(note);

        return scroll;
    }

    private void updateStatus() {
        if (status == null) return;
        String s;
        if (BassService.globalOk) {
            s = "✓ Working on all audio";
        } else if (BassService.sessionCount > 0) {
            s = "✓ Working on music apps that support it (Spotify, YouTube Music…)";
        } else {
            s = "Global EQ not allowed on this unit. Start music in Spotify/YouTube Music, then reopen this app.";
        }
        if (!eqInfoOk) s += "  (EQ bands unknown, using defaults)";
        status.setText(s);
    }

    // ---------- Presets ----------

    private void applyPreset(int which) {
        int bass, loud;
        switch (which) {
            case 1: bass = 600; loud = 200; break;   // Bass Heavy
            case 2: bass = 400; loud = 200; break;   // Bass + Clear
            case 3: bass = 300; loud = 400; break;   // Night (low volume)
            default: bass = 0; loud = 0;             // Flat
        }
        bassBar.setProgress(bass);
        loudBar.setProgress(loud);
        for (int i = 0; i < bandCount; i++) {
            int f = centerHz[i];
            int db;   // in tenths of dB * 10 = millibels
            switch (which) {
                case 1: db = f <= 150 ? 800 : f <= 500 ? 300 : f <= 4000 ? 0 : 200; break;
                case 2: db = f <= 150 ? 600 : f <= 500 ? 100 : f <= 4000 ? -100 : 400; break;
                case 3: db = f <= 150 ? 500 : f <= 500 ? 200 : f <= 4000 ? 0 : 300; break;
                default: db = 0;
            }
            bandBars[i].setProgress(clamp(db) - minLevel);
        }
    }

    // ---------- helpers ----------

    interface IntChange { void on(int v); }

    private SeekBar bar(int max, int value, IntChange change) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setMinimumHeight(dp(48));
        sb.setPadding(dp(16), dp(12), dp(16), dp(20));
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(ORANGE));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(ORANGE));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) { change.on(p); }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        sb.setProgress(value);
        change.on(value);   // set the label even if the value didn't change
        return sb;
    }

    private Button presetButton(String label, int which) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF2A2A2A);
        bg.setStroke(dp(2), ORANGE);
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        b.setMinHeight(dp(56));
        b.setOnClickListener(v -> applyPreset(which));
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private TextView section(String s) {
        TextView t = text(s, 22, ORANGE, true);
        t.setPadding(0, dp(20), 0, dp(6));
        return t;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int clamp(int level) {
        return Math.max(minLevel, Math.min(maxLevel, level));
    }

    private static String hz(int f) {
        return f >= 1000 ? String.format(Locale.US, "%.1f kHz", f / 1000f) : f + " Hz";
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }
}
